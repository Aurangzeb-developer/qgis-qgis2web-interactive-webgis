var json_03_roads_4 = {
"type": "FeatureCollection",
"name": "03_roads_4",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{"type":"Feature","properties":{"Road_Name":"Avenue 1","Road_Type":"Local Road"},"geometry":{"type":"LineString","coordinates":[[74.29975,31.49992],[74.3069,31.49992]]}},
{"type":"Feature","properties":{"Road_Name":"Avenue 2","Road_Type":"Local Road"},"geometry":{"type":"LineString","coordinates":[[74.29975,31.50077],[74.3069,31.50077]]}},
{"type":"Feature","properties":{"Road_Name":"Avenue 3","Road_Type":"Local Road"},"geometry":{"type":"LineString","coordinates":[[74.29975,31.50162],[74.3069,31.50162]]}},
{"type":"Feature","properties":{"Road_Name":"Avenue 4","Road_Type":"Local Road"},"geometry":{"type":"LineString","coordinates":[[74.29975,31.50247],[74.3069,31.50247]]}},
{"type":"Feature","properties":{"Road_Name":"Avenue 5","Road_Type":"Local Road"},"geometry":{"type":"LineString","coordinates":[[74.29975,31.50332],[74.3069,31.50332]]}},
{"type":"Feature","properties":{"Road_Name":"Street 1","Road_Type":"Access Street"},"geometry":{"type":"LineString","coordinates":[[74.29992,31.49975],[74.29992,31.5034]]}},
{"type":"Feature","properties":{"Road_Name":"Street 2","Road_Type":"Access Street"},"geometry":{"type":"LineString","coordinates":[[74.30107,31.49975],[74.30107,31.5034]]}},
{"type":"Feature","properties":{"Road_Name":"Street 3","Road_Type":"Access Street"},"geometry":{"type":"LineString","coordinates":[[74.30222,31.49975],[74.30222,31.5034]]}},
{"type":"Feature","properties":{"Road_Name":"Street 4","Road_Type":"Access Street"},"geometry":{"type":"LineString","coordinates":[[74.30337,31.49975],[74.30337,31.5034]]}},
{"type":"Feature","properties":{"Road_Name":"Street 5","Road_Type":"Access Street"},"geometry":{"type":"LineString","coordinates":[[74.30452,31.49975],[74.30452,31.5034]]}},
{"type":"Feature","properties":{"Road_Name":"Street 6","Road_Type":"Access Street"},"geometry":{"type":"LineString","coordinates":[[74.30567,31.49975],[74.30567,31.5034]]}},
{"type":"Feature","properties":{"Road_Name":"Street 7","Road_Type":"Access Street"},"geometry":{"type":"LineString","coordinates":[[74.30682,31.49975],[74.30682,31.5034]]}}
]
}
