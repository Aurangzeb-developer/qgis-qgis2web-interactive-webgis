var json_04_buildings_3 = {
"type": "FeatureCollection",
"name": "04_buildings_3",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{"type":"Feature","properties":{"Building_ID":"B-001","Type":"Commercial","Floors":1.0},"geometry":{"type":"Polygon","coordinates":[[[74.30023276,31.50015334],[74.3007084,31.50015334],[74.3007084,31.50046002],[74.30023276,31.50046002],[74.30023276,31.50015334]]]}},
{"type":"Feature","properties":{"Building_ID":"B-002","Type":"Residential","Floors":3.0},"geometry":{"type":"Polygon","coordinates":[[[74.30253276,31.50015334],[74.30300840000001,31.50015334],[74.30300840000001,31.50046002],[74.30253276,31.50046002],[74.30253276,31.50015334]]]}},
{"type":"Feature","properties":{"Building_ID":"B-003","Type":"Commercial","Floors":2.0},"geometry":{"type":"Polygon","coordinates":[[[74.30483276,31.50015334],[74.3053084,31.50015334],[74.3053084,31.50046002],[74.30483276,31.50046002],[74.30483276,31.50015334]]]}},
{"type":"Feature","properties":{"Building_ID":"B-004","Type":"Residential","Floors":1.0},"geometry":{"type":"Polygon","coordinates":[[[74.30023276,31.50100334],[74.3007084,31.50100334],[74.3007084,31.50131002],[74.30023276,31.50131002],[74.30023276,31.50100334]]]}},
{"type":"Feature","properties":{"Building_ID":"B-005","Type":"Commercial","Floors":3.0},"geometry":{"type":"Polygon","coordinates":[[[74.30253276,31.50100334],[74.30300840000001,31.50100334],[74.30300840000001,31.50131002],[74.30253276,31.50131002],[74.30253276,31.50100334]]]}},
{"type":"Feature","properties":{"Building_ID":"B-006","Type":"Residential","Floors":2.0},"geometry":{"type":"Polygon","coordinates":[[[74.30483276,31.50100334],[74.3053084,31.50100334],[74.3053084,31.50131002],[74.30483276,31.50131002],[74.30483276,31.50100334]]]}},
{"type":"Feature","properties":{"Building_ID":"B-007","Type":"Commercial","Floors":1.0},"geometry":{"type":"Polygon","coordinates":[[[74.30023276,31.50185334],[74.3007084,31.50185334],[74.3007084,31.50216002],[74.30023276,31.50216002],[74.30023276,31.50185334]]]}},
{"type":"Feature","properties":{"Building_ID":"B-008","Type":"Residential","Floors":3.0},"geometry":{"type":"Polygon","coordinates":[[[74.30253276,31.50185334],[74.30300840000001,31.50185334],[74.30300840000001,31.50216002],[74.30253276,31.50216002],[74.30253276,31.50185334]]]}},
{"type":"Feature","properties":{"Building_ID":"B-009","Type":"Commercial","Floors":2.0},"geometry":{"type":"Polygon","coordinates":[[[74.30483276,31.50185334],[74.3053084,31.50185334],[74.3053084,31.50216002],[74.30483276,31.50216002],[74.30483276,31.50185334]]]}},
{"type":"Feature","properties":{"Building_ID":"B-010","Type":"Residential","Floors":1.0},"geometry":{"type":"Polygon","coordinates":[[[74.30023276,31.50270334],[74.3007084,31.50270334],[74.3007084,31.50301002],[74.30023276,31.50301002],[74.30023276,31.50270334]]]}},
{"type":"Feature","properties":{"Building_ID":"B-011","Type":"Commercial","Floors":3.0},"geometry":{"type":"Polygon","coordinates":[[[74.30253276,31.50270334],[74.30300840000001,31.50270334],[74.30300840000001,31.50301002],[74.30253276,31.50301002],[74.30253276,31.50270334]]]}},
{"type":"Feature","properties":{"Building_ID":"B-012","Type":"Residential","Floors":2.0},"geometry":{"type":"Polygon","coordinates":[[[74.30483276,31.50270334],[74.3053084,31.50270334],[74.3053084,31.50301002],[74.30483276,31.50301002],[74.30483276,31.50270334]]]}}
]
}
